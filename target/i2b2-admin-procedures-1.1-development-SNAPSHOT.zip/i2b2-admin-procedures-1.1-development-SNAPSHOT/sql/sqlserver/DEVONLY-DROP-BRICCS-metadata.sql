drop table ONT_PROCESS_STATUS ;
drop table ONYX ;
drop table BIRN ;
drop table SCHEMES ;
drop table TABLE_ACCESS ;
drop table CUSTOM_META ;