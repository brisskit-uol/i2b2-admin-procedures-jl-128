drop table WORKPLACE ;
drop table WORKPLACE_ACCESS ;